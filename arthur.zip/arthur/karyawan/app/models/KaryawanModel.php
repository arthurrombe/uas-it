<?php

class KaryawanModel {

    private $table = "karyawan";
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function getAllKaryawan() {
        $this->db->query("SELECT karyawan.*, kategori.nama_kategori FROM " . $this->table . " JOIN kategori ON kategori.nama_kategori = karyawan.kategori_nama");
        return $this->db->resultSet();
    }

    public function tambahKaryawan($data) {
        $this->db->query("INSERT INTO karyawan (nama, alamat, status, kategori_nama, jumlah_anak, agama ) 
            VALUES (:nama, :alamat, :status, :kategori_nama, :jumlah_anak, :agama)");
        $this->db->bind('nama', $data['nama']);
        $this->db->bind('alamat', $data['alamat']);
        $this->db->bind('status', $data['status']);
        $this->db->bind('kategori_nama', $data['kategori_nama']);
        $this->db->bind('jumlah_anak', $data['jumlah_anak']);
        $this->db->bind('agamal', $data['agama']);
        $this->db->execute();

        return $this->db->rowCount();
    }


    public function getKaryawanById($id){
        $this->db->query('SELECT * FROM ' . $this->table . ' WHERE id = :id');
        $this->db->bind('id', $id);
        return $this->db->single();
    }
    

    public function updateDataKaryawan($data) {
        $this->db->query("UPDATE karyawan SET nama=:nama, 'alamat`=:alamat, status=:status, kategori_nama=:kategori_nama, jumlah_anak=:jumlah_anak, agama=:agama WHERE id=:id");
        $this->db->bind('id', $data['id']);
        $this->db->bind('nama', $data['nama']);
        $this->db->bind('alamat', $data['alamat']);
        $this->db->bind('status', $data['status']);
        $this->db->bind('kategori_nama', $data['kategori_nama']);
        $this->db->bind('jumlah_anak', $data['jumlah_anak']);
        $this->db->bind('agama', $data['agama']);
        $this->db->execute();
    
        return $this->db->rowCount();
    }
    

    public function cariKaryawan() {
        $key = $_POST['key'];
        $this->db->query("SELECT * FROM " . $this->table . " WHERE nama LIKE :key 
                          OR alamat LIKE :key 
                          OR status LIKE :key 
                          OR kategori_nama LIKE :key 
                          OR jumlah_anak LIKE :key 
                          OR agama LIKE :key");
        $this->db->bind(':key', "%$key%", PDO::PARAM_STR);
        return $this->db->resultSet();
    }
    
    
    

    public function deleteKaryawan($id){
        $this->db->query('DELETE FROM ' . $this->table . ' WHERE id=:id');
        $this->db->bind('id',$id);
        $this->db->execute();
    
        return $this->db->rowCount();
    }


    
    



}



?>
