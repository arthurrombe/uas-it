<div class="content-wrapper">

    <section class="content-header">

        <div class="container-fluid">

            <div class="row mb-2">

                <div class="col-sm-6">

                    <h1><?= $data['title']; ?></h1>

                </div>

            </div>

        </div>

    </section>

    <section class="content">

        <div class="card card-primary">

            <div class="card-header">

                <h3 class="card-title"><?= $data['title']; ?></h3>

            </div>

            <form role="form" action="<?= base_url; ?>/karyawan/updateKaryawan" method="POST" enctype="multipart/form-data">

                <input type="hidden" name="id" value="<?= $data['karyawan']['id']; ?>">

                <div class="card-body">

                    <div class="form-group">

                        <label >Nama </label>

                        <input type="text" class="form-control" placeholder="masukkan nama..." name="nama" value="<?= $data['karyawan']['nama'];?>">

                    </div>

                    <div class="form-group">

                        <label >Alamat </label>

                        <input type="text" class="form-control" placeholder="masukkan alamat..." name="alamat" value="<?= $data['karyawan']['alamat'];?>">

                    </div>

                    <div class="form-group">

                        <label> status </label>

                        <input type="text" class="form-control" placeholder="masukka status..." name="status" value="<?= $data['karyawan']['status'];?>">

                    </div>

                    <div class="form-group">

                        <label >Kategori </label>

                        <select class="form-control" name="kategori_nama">

                            <option value="">Pilih Kategori</option>

                            <?php foreach ($data['kategori'] as $row) :?>

                                <option value="<?= $row['nama_kategori']; ?>" <?php if($data['karyawan']['kategori_nama'] == $row['nama_kategori']) { echo "selected"; } ?>><?= $row['nama_kategori']; ?></option>

                            <?php endforeach; ?>

                        </select>

                    </div>
 
                    <div class="form-group">

                        <label >jumlah anak</label>

                        <input type="number" class="form-control" placeholder="masukkan jumlah ..." name="jumlah" value="<?= $data['karyawan']['jumlah_anak'];?>">

                    </div>

                    <div class="form-group">

                        <label >agama</label>

                        <input type="text" class="form-control" placeholder="masukkan agama..." name="agama" value="<?= $data['karyawan']['agama'];?>">

                    </div> 

                </div>

                <div class="card-footer">

                    <button type="submit" class="btn btn-primary">Submit</button>

                </div>

            </form>

        </div>

    </section>

</div>