<?php
class karyawan extends Controller {

    public function __construct(){

        if($_SESSION['session_login'] != 'sudah_login') {
            
        Flasher::setMessage('Login','Tidak ditemukan.','danger');
        header('location: '. base_url . '/login');
        exit;
        
        }
    }

    public function index(){
        $data['title']='Data Karyawan Perusahaan';
        $data['Karyawan']=$this->model('KaryawanModel')->getAllKaryawan();
        $this->view('templates/header', $data);
        $this->view('templates/sidebar', $data);
        $this->view('karyawan/index', $data);
        $this->view('templates/footer');
    }




    public function tambahKaryawan(){
        $data['title'] = 'Tambah Data Karyawan Perusahaan';
        $data['kategori']=$this->model('KategoriModel')->getAllKategori();
        $this->view('templates/header', $data);
        $this->view('templates/sidebar', $data);
        $this->view('karyawan/create', $data);
        $this->view('templates/footer');
    }
    public function simpanKaryawan(){
        if( $this->model('KaryawwanModel')->tambahKaryawan($_POST) > 0 ){
            Flasher::setMessage('Berhasil','ditambahkan', 'success');
            header('location: ' . base_url . '/karyawan');
            exit;
        }else{
            Flasher::setMessage('Gagal', 'ditambahkan', 'danger');
            header('location: ' . base_url . '/karyawan');
            exit;
        }
    }  



    
    public function editPermintaan($id){
        $data['title'] = 'Detail Karyawan Perusahaan';
        $data['kategori']=$this->model('KategoriModel')->getAllKategori();
        $data['karyawan'] = $this->model('katyawanModel')->getKaryawanById($id);
        $this->view('templates/header', $data);
        $this->view('templates/sidebar', $data);
        $this->view('karyawan/edit', $data);
        $this->view('templates/footer');
    }
    public function updateKaryawan(){
        if( $this->model('KaryawanModel')->updateDataKaryawan($_POST) > 0 ){
            Flasher::setMessage('Berhasil','diupdate', 'success');
            header('location: ' . base_url . '/karyawan');
            exit;
        }else{
            Flasher::setMessage('Gagal', 'diupdate', 'danger');
            header('location: ' . base_url . '/karyawan');
            exit;
        }
    }  


    

    public function cariKaryawan(){
        $data['title'] = 'Data Karyawan Perusahaan';
        $data['karyawan'] = $this->model('KaryawanModel')->cariKaryawan();
        $data['key'] = $_POST['key'];
        $this->view('templates/header', $data);
        $this->view('templates/sidebar', $data);
        $this->view('karyawan/index', $data);
        $this->view('templates/footer');
    }
    public function hapusKaryawan($id){
        if( $this->model('KaryawanModel')->deleteKaryawan($id) > 0 ){
            Flasher::setMessage('Berhasil','dihapus', 'success');
            header('location: ' . base_url . '/karyawan');
            exit;
        }else{
            Flasher::setMessage('Gagal', 'dihapus', 'danger');
            header('location: ' . base_url . '/karyawan');
            exit;
        }
    }  



}
